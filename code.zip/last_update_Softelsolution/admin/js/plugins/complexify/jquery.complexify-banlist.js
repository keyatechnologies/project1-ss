// Generated from 500 worst passwords and 370 Banned Twitter lists found at
// @source http://www.skullsecurity.org/wiki/index.php/Passwords
COMPLEXIFY_BANLIST = [];