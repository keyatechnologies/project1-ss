<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
$hostname='localhost'; // database host name
$username='shaktico_softel';// database user name
$password='softel';// database password
$db_name='shaktico_softelsolution';//database name

mysql_connect($hostname,$username,$password) or die('Fail To Connect MySQL Server');
mysql_select_db($db_name) or die('Database Connection Fail');
?>