<?php 
	require_once(ROOT.'m/Services/twitterOAuth/twitterOAuth.php');
	require_once(ROOT.'m/Services/twitterOAuth/OAuth.php');
	echo $instance['domain'];
	switch ($instance ['domain']) {
		case ('my.isocialreviews.com') :
			{
				$consumer_key = 'w4jhYDtNxgE1ng0n74zj2Q';
				$consumer_secret = 'W5b4sJe5wW3rUGdAPxJs4AL4trk4QY20TwU6CpxnQRM';
				break;
			}
		case ('my.easyonlinereviews.com') :
			{
				$consumer_key = 'Lzkka2oNo83AHAF7xho9A';
				$consumer_secret = 'ZcoIV2xyuEbgI6SgrUQzk9QofcR5Tk9D8r0Aay8DJO4';
				break;
			}
		case ('my.itackitreviews.com') :
			{
				$consumer_key = 'FeT0ssc60LJdqkWy3TIlQ';
				$consumer_secret = '9KZYH1HLDOsXsEYCYdMjyUmrJI4DK4asXdLGWknXY';
				break;
			}
		case ('dashboard.fivestarmax.com') :
			{
				$consumer_key = '6nZsxCI491m5iqUD6O99g';
				$consumer_secret = 'g1rhrkYhM0zq2wjRMNcLvon1UMPCGorCodHgk33di0';
				break;
			}
		default :
			{
				$consumer_key = '1dlFLjX2lut7HWCSmod1lQ';
				$consumer_secret = 'mkIhj04dXrrpVaya9FubA11TNg0NP11u2bQiSa6aNMs';
				break;
			}
	}

?>