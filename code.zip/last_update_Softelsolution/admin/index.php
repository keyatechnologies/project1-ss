<?php
	error_reporting(0);
	session_start();
	include_once('include/dbconnect.php');
	include_once('include/functions.php');
	
	require_once("../model/slider.class.php");
	require_once("../model/pages.class.php");
	require_once("../model/browse_position.class.php");
	require_once("../model/users.class.php");
	require_once("../model/category.class.php");
	require_once("../model/photos.class.php");
	require_once("../model/image.class.php");
	
	# Set absolute path
	$froot = $_SERVER['DOCUMENT_ROOT']."/";
	$root = $_SERVER['DOCUMENT_ROOT']."/admin/";
	$host = "http://".$_SERVER['HTTP_HOST']."/admin/";
	$fhost = "http://".$_SERVER['HTTP_HOST']."/";
	define('FROOT',$froot);
	define('FHOST',$fhost);
	define('ROOT',$root);
	define('HOST',$host);
	define('CSS',$host."css/");
	define('JS',$host."js/");
	define('IMG',$host."img/");
	# End absolute path
		
	$f3 = require('lib/base.php');
	$title = "Softel Solutions";
	
	$f3->route('GET /404',
	    function($f3) 
		{
			global $title;
			$title = "404 Page Not Found";
			$page = "404";
        	#include_once('header.php');
        	include_once('app/404.php');
        	#include_once('footer.php');
	    }
	);
	
	$f3->route('GET /',
	    function($f3) 
		{
			global $title;
			$page = "index";
        	include_once('app/header.php');
        	//include_once('app/home.php');
			include_once('app/pages.php');
        	include_once('app/footer.php');
	    }
	);
	
	$f3->route('GET /login',
	    function($f3) 
		{
			global $title;
			$page = "login";
        	include_once('app/login.php');
	    }
	);
	$f3->route('POST /login',
	    function($f3) 
		{
        	include_once('api/login.php');
	    }
	);
	
	$f3->route('GET /slider',
	    function($f3) 
		{
			global $title;
			$page = "slider";
        	include_once('app/header.php');
        	include_once('app/slider.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /slider',
	    function($f3) 
		{
        	include_once('api/slider.php');
	    }
	);
	
	$f3->route('GET /pages',
	    function($f3) 
		{
			global $title;
			$page = "pages";
        	include_once('app/header.php');
        	include_once('app/pages.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('GET /pages/@id',
	    function($f3,$param) 
		{
			global $title;
			$page = "pages";
			$id = $param["id"];
			include_once('app/header.php');
        	include_once('app/page_edit.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('GET /browse-positions',
	    function($f3) 
		{
			global $title;
			$page = "browse-positions";
        	include_once('app/header.php');
        	include_once('app/browse-position.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /browse-positions',
	    function($f3,$param) 
		{
			global $title;
			$page = "browse-positions";
        	include_once('api/browse-position.php');
	    }
	);
	$f3->route('POST /pages/@id',
	    function($f3,$param) 
		{
			global $title;
			$page = "pages";
			$id = $param["id"];
        	include_once('api/page_edit.php');
	    }
	);
	$f3->route('GET /services',
	    function($f3) 
		{
			global $title;
			$page = "services";
        	include_once('app/header.php');
        	include_once('app/services.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /services',
	    function($f3) 
		{
        	include_once('api/services.php');
	    }
	);
	
	$f3->route('GET /clients',
	    function($f3) 
		{
			global $title;
			$page = "clients";
        	include_once('app/header.php');
        	include_once('app/clients.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /clients',
	    function($f3) 
		{
        	include_once('api/clients.php');
	    }
	);
	
	$f3->route('GET /testimonial',
	    function($f3) 
		{
			global $title;
			$page = "testimonial";
        	include_once('app/header.php');
        	include_once('app/testimonial.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /testimonial',
	    function($f3) 
		{
        	include_once('api/testimonial.php');
	    }
	);
	
	$f3->route('GET /portfolio',
	    function($f3) 
		{
			global $title;
			$page = "portfolio";
        	include_once('app/header.php');
        	include_once('app/portfolio.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /portfolio',
	    function($f3) 
		{
        	include_once('api/portfolio.php');
	    }
	);
	
	$f3->route('GET /portfolio/@id',
	    function($f3,$param) 
		{
			global $title;
			$page = "portfolio";
			$cat  =$param['id'];
        	include_once('app/header.php');
        	include_once('app/portfolio_add.php');
        	include_once('app/footer.php');
	    }
	);
	$f3->route('POST /portfolio@id',
	    function($f3,$param)
		{
			$cat  =$param['id'];
        	include_once('api/portfolio_add.php');
	    }
	);
	$f3->route('GET /contact',
	    function($f3) 
		{
			global $title;
			$page = "contact";
        	include_once('header.php');
        	include_once('contact.php');
        	include_once('footer.php');
	    }
	);
	$f3->run();
?>