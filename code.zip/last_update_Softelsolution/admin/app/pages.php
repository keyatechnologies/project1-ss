<div id="main">
    <div class="container-fluid">
        <br />
        <div class="row-fluid">
            <div class="span8">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Pages
                        </h3>
                    </div>
                    <div class="box-content nopadding">
                        <table class="table table-hover table-nomargin table-bordered">
                            <thead>
                                <tr>
                                    <th width="10">#</th>
                                    <th>Title</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
							$get_val = new Pages();
							$get_val = $get_val->search();
							$i=0;
							foreach($get_val as $page)
							{
								$i++;
								?>
                                <tr>
                                    <td><?=$i?></td>
                                    <td><a href="<?=HOST?>pages/<?=$page->id?>"><?=$page->title?></a></td>
                                </tr>
                                <?php
							}
							?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>