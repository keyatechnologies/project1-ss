<div id="main">
	<div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="box">
                    <div class="box-title">
                        <h3>
                            <i class="icon-file"></i>
                            File manager
                        </h3>
                    </div>
                    <div class="box-content nopadding">
                        
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>