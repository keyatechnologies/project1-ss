<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!-- Apple devices fullscreen -->
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<!-- Apple devices fullscreen -->
	<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	
	<title><?=$title?></title>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap.min.css">
	<!-- Bootstrap responsive -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap-responsive.min.css">
	<!-- Theme CSS -->
	<link rel="stylesheet" href="<?=CSS?>style.css">
	<!-- Color CSS -->
	<link rel="stylesheet" href="<?=CSS?>themes.css">


	<!-- jQuery -->
	<script src="<?=JS?>jquery.min.js"></script>
	
	<!-- Nice Scroll -->
	<script src="<?=JS?>plugins/nicescroll/jquery.nicescroll.min.js"></script>
	<!-- Bootstrap -->
	<script src="<?=JS?>bootstrap.min.js"></script>

	<!--[if lte IE 9]>
		<script src="<?=JS?>plugins/placeholder/jquery.placeholder.min.js"></script>
		<script>
			$(document).ready(function() {
				$('input, textarea').placeholder();
			});
		</script>
	<![endif]-->
	

	<!-- Favicon -->
	<link rel="shortcut icon" href="<?=IMG?>favicon.ico" />
	<!-- Apple devices Homescreen icon -->
	<link rel="apple-touch-icon-precomposed" href="<?=IMG?>apple-touch-icon-precomposed.png" />

</head>

<body class='error'>
	<div class="wrapper">
		<div class="code"><span>404</span><i class="icon-warning-sign"></i></div>
		<div class="desc">Oops! Sorry, that page could'nt be found.</div>
		<form action="more-searchresults.html" class='form-horizontal'>
			<div class="input-append">
				<input type="text" name="search" placeholder="Search a site..">
				<button type='submit' class='btn'><i class="icon-search"></i></button>
			</div>
		</form>
		<div class="buttons">
			<div class="pull-left"><a href="<?=HOST?>" class="btn"><i class="icon-arrow-left"></i> Back</a></div>
		</div>
	</div>
	
</body>

</html>
