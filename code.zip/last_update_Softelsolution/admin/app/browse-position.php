<?php
$objC = new Browse_position();
$get_val = new Browse_position();
$get_val = $get_val->search("","id desc");
?>
<div id="main">
	<div id="new-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Add new position</h3>
		</div>
		<form id="frmNewGallery" method="post" class='form-horizontal form-bordered'>
			<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Position Name</label>
					<div class="controls">
						<input type="text" name="new_pos_name" id="new_pos_name" class="input-block-level" placeholder="Enter position name">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Primary Skill Set </label>
					<div class="controls">
						<input type="text" name="new_primary_skill_set" id="new_primary_skill_set" class="input-block-level" placeholder="Enter primary skill set">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Location </label>
					<div class="controls">
						<input type="text" name="new_location" id="new_location" class="input-block-level" placeholder="Enter location">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Duration </label>
					<div class="controls">
						<input type="text" name="new_duration" id="new_duration" class="input-block-level" placeholder="Enter duration">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Type of Job  </label>
					<div class="controls">
						<input type="text" name="new_type_of_job" id="new_type_of_job" class="input-block-level" placeholder="Enter type of job">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Job Description </label>
					<div class="controls">
						<input type="text" name="new_job_desc" id="new_job_desc" class="input-block-level" placeholder="Enter job description">
					</div>
				</div>
			</div>
			<div class="modal-footer">
            	<input type="hidden" name="action" value="add" />
                <button type="button" id="addS" class="btn btn-primary" onclick="addNS();"><i class="icon-save"></i> Save <i id="addSL" class=""></i></button>
                <button type="button" id="addSC" data-dismiss="modal" aria-hidden="true" class="btn">Cancel</button>
                <button type="submit" id="add-submit" class="hide"></button>
                <input type="reset" id="add_new_reset" name="add_new_reset" class="hide" />
			</div>
		</form>

	</div>
    <div id="edit-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Edit Position</h3>
		</div>
		<form id="frmEditGallery"  method="post"class='new-task-form form-horizontal form-bordered'>
        	<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Position Name</label>
					<div class="controls">
						<input type="text" name="edit_pos_name" id="edit_pos_name" class="input-block-level" placeholder="Enter position name">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Primary Skill Set </label>
					<div class="controls">
						<input type="text" name="edit_primary_skill_set" id="edit_primary_skill_set" class="input-block-level" placeholder="Enter primary skill set">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Location </label>
					<div class="controls">
						<input type="text" name="edit_location" id="edit_location" class="input-block-level" placeholder="Enter location">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Duration </label>
					<div class="controls">
						<input type="text" name="edit_duration" id="edit_duration" class="input-block-level" placeholder="Enter duration">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Type of Job  </label>
					<div class="controls">
						<input type="text" name="edit_type_of_job" id="edit_type_of_job" class="input-block-level" placeholder="Enter type of job">
					</div>
				</div>
                <div class="control-group">
					<label for="service-title" class="control-label">Job Description </label>
					<div class="controls">
						<input type="text" name="edit_job_desc" id="edit_job_desc" class="input-block-level" placeholder="Enter job description">
					</div>
				</div>
			</div>
			<div class="modal-footer">
            	<input type="hidden" name="action" value="edit" />
                <input type="hidden" name="id" id="edit-id" value="0" />
                <button type="button" id="editS" class="btn btn-primary" onclick="editNS();"><i class="icon-save"></i> Save</button>
                <button type="button" id="editSC" data-dismiss="modal" aria-hidden="true" class="btn" >Cancel</button>
			</div>
		</form>

	</div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Browse Positions
                        </h3>
                        <div class="actions">
                        	<a href="javascript://" onclick="openAdd();" class='btn'><i class="icon-plus-sign"></i> Add Position</a>
                            <a id="openAdd" href="#new-service" data-toggle="modal" class='btn hide'></a>
                            <a id="openEdit" href="#edit-service" data-toggle="modal" class='btn hide'></a>
                        </div>
                    </div>
                    <div class="box-content nopadding">
                        <table class="table table-hover table-nomargin table-bordered">
                            <thead>
                                <tr>
                                    <th>Position </th>
                                    <th>Primary Skill Set</th>
                                    <th>Location</th>
                                    <th>Duration</th>
                                    <th>Type of Job</th>
                                    <th>Job Description</th>
                                    <th width="75">Action</th>
                                </tr>
                            </thead>
                            <tbody id="services-list">
                            <?php
							if($get_val)
							{
								foreach($get_val as $position)
								{
								?>
								<tr id="title_<?=$position->id?>">
                                    <td id="pos_name_<?=$position->id?>"><?=$position->pos_name?></td>
                                    <td id="primary_skill_<?=$position->id?>"><?=$position->primary_skill?></td>
                                    <td id="location_<?=$position->id?>"><?=$position->location?></td>
                                    <td id="duration_<?=$position->id?>"><?=$position->duration?></td>
                                    <td id="type_of_job_<?=$position->id?>"><?=$position->type_of_job?></td>
                                    <td id="job_desc_<?=$position->id?>"><?=$position->job_desc?></td>
                                    <td>
                                        <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$position->id?>')" class="btn btn-mini btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
                                        <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$position->id?>')" class="btn btn-mini btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
                                    </td>
                                </tr>
								<?php		
								}
							}
							?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var ele = "";
	var sid = "0";
	function openAdd()
	{
		$("#addSL").removeClass("icon-spinner");
		$("#addSL").removeClass("icon-spin");
		$("#addS").attr("disabled",false);
		$("#add_new_reset").trigger("click");
		$("#openAdd").trigger("click");
	}
	function openEdit(id)
	{
		$("#edit_pos_name").val($("#pos_name_"+id).html());
		$("#edit_primary_skill_set").val($("#primary_skill_"+id).html());
		$("#edit_location").val($("#location_"+id).html());
		$("#edit_duration").val($("#duration_"+id).html());
		$("#edit_type_of_job").val($("#type_of_job_"+id).html());
		$("#edit_job_desc").val($("#job_desc_"+id).html());
		$("#edit-id").val(id);
		$("#openEdit").trigger("click");
	}
	function editNS()
	{
		var id = $("#edit-id").val();
		var frm = $("#frmEditGallery").serialize();
		$("#editSC").trigger("click");
		
		//$("#title_"+id).html($("#edit-gallery-title").val());
		$("#pos_name_"+id).html($("#edit_pos_name").val());
		$("#primary_skill_"+id).html($("#edit_primary_skill_set").val());
		$("#location_"+id).html($("#edit_location").val());
		$("#duration_"+id).html($("#edit_duration").val());
		$("#type_of_job_"+id).html($("#edit_type_of_job").val());
		$("#job_desc_"+id).html($("#edit_job_desc").val());
		$.ajax({
			url:"<?=HOST?>browse-positions",
			type:"POST",
			data:frm,
			success:function(res){
			}
		})
	}
	function addNS()
	{
		$("#addSL").addClass("icon-spinner");
		$("#addSL").addClass("icon-spin");
		$("#addS").attr("disabled",true);
		$("#add-submit").trigger("click");
	}
	function deleteS(ele,id)
	{
		sid = id;
		bootbox.confirm("Do you really want to remove this Position?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).parent("td").parent("tr").remove();
					$.ajax({
						url:"<?=HOST?>browse-positions",
						type:"POST",
						data:"action=delete&id="+sid,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
</script>