<?php
$get_val = new Pages();
$get_val = $get_val->getById($id);
if(!$get_val)
{
	$f3->reroute("/pages/");
}
?>
<div id="main">
    <div class="container-fluid">
        
        
        <div class="row-fluid">
            <div class="span12">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Edit Page
                        </h3>
                    </div>
                    <div class="box-content nopadding">
                        <form action="" method="POST" class='form-vertical form-bordered form-wysiwyg'>
                            <div class="control-group">
                                <label for="title" class="control-label">Page Title</label>
                                <div class="controls">
                                    <input type="text" name="pagetitle" id="pagetitle" placeholder="Enter Page Title" class="input-xlarge" value="<?=$get_val->title?>">
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="pagedesc" class="control-label">Page Description</label>
                                <div class="controls" style="border-top:1px solid #DDDDDD;">
                                    <textarea name="ck" id="pagedesc" rows="5" class="ckeditor span12"><?=$get_val->description?></textarea>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                                <button type="button" class="btn">Cancel</button>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>