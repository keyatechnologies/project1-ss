<?php
$testimonials = new Testimonial();
$testimonials = $testimonials->search("","","id desc");
?>
<div id="main">
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Testimonial
                        </h3>
                    </div>
                    <div class="box-content nopadding">
                        <div class="search-results">
                            <ul>
							<?php
                            if($testimonials)
                            {
                                foreach($testimonials as $testimonial)
                                {
                                ?>
                                <li>
                                    <div class="search-info" style="margin-left:0;">
                                        <a href="javascript://"><?=setGPC(ucfirst($testimonial->name),"display");?></a>
                                        <p class="url"><?=setGPC(ucfirst($testimonial->email),"display");?></p>
                                        <p><?=setGPC($testimonial->testimonial,"display");?></p>
                                        <?php
										if($testimonial->status == "0")
										{
											?><button type="button" class="btn btn-mini btn-green" onclick="approvT(this,'<?=$testimonial->id?>')"><i class="icon-check"></i> Approved</button><?php
										}
										?>
                                        <button type="button" class="btn btn-mini btn-danger" onclick="deleteT(this,'<?=$testimonial->id?>')"><i class="icon-trash"></i> Delete</button>
                                    </div>
                                </li>
                                <?php
                                }
                            }
                            ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var ele = "";
	var sid = "0";
	function deleteT(ele,id)
	{
		sid = id;
		bootbox.confirm("Do you really want to remove this Testimonial?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).parent("div").parent("li").fadeOut(1000);
					$.ajax({
						url:"<?=HOST?>testimonial",
						type:"POST",
						data:"action=delete&id="+sid,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
	function approvT(ele,id)
	{
		sid = id;
		bootbox.confirm("Do you really want to <strong>Approved</strong> this Testimonial?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).fadeOut(1000);
					$.ajax({
						url:"<?=HOST?>testimonial",
						type:"POST",
						data:"action=edit&id="+sid,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
</script>