<?php
$get_val = new Category();
$get_val = $get_val->getById($cat);
if(!$get_val)
{
	$f3->reroute("/gallery");
}
$photos = new Photos();
$photos = $photos->search("cat=".$cat,"","id desc");
?>
<div id="main">
	<div id="new-slider" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Upload Image</h3>
		</div>
		<form id="frmNewSlider" method="post" class='new-task-form form-horizontal form-bordered' enctype="multipart/form-data">
			<div class="modal-body nopadding">
				<div class="control-group">
                    <label for="textfield" class="control-label">Title</label>
                    <div class="controls">
                    	<input type="text" name="img_title" id="img_title" placeholder="Enter image title" />
                    </div>
                </div>
                <div class="control-group">
                    <label for="textfield" class="control-label"></label>
                    <div class="controls">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                            <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;"><img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&text=no+image" /></div>
                            <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                            <div>
                                <span class="btn btn-file"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input type="file" name='imagefile' id="imagefile" /></span>
                                <a href="javascript://" id="removeImage" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
			<div class="modal-footer">
            	<input type="hidden" name="action" value="add" />
                <input type="hidden" name="cat" value="<?=$cat?>" />
                <button type="button" id="addS" class="btn btn-primary" onclick="addNS();"><i class="icon-save"></i> Upload <i id="addSL" class=""></i></button>
                <button type="button" id="addSC" data-dismiss="modal" aria-hidden="true" class="btn">Cancel</button>
			</div>
		</form>

	</div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="box box-condensed">
                    <div class="box-title">
                        <h3>
                            <i class="icon-picture"></i>
                            <?=$get_val->name?>
                        </h3>
                        <div class="pull-right">
                        	<a href="javascript://" onclick="openUpload();" class="btn btn-danger"><i class="icon-cloud-upload"></i> Upload images</a>
                            <a id="openUpload" href="#new-slider" data-toggle="modal" class='btn hide'></a>
                        </div>
                    </div>
                    <div class="box-content nopadding">
                    	<br />
                        <ul class="gallery" id="imageGallery">
                        <?php
                        if($photos)
                        {
                            foreach($photos as $photo)
                            {
                            ?>
                            <li>
                                <a href="javascript://">
                                    <img src="<?=FHOST?>upload/gallery/thumb/<?=$photo->image?>" alt="">
                                </a>
                                <div class="extras">
                                    <div class="extras-inner">
                                        <a href="<?=FHOST?>upload/gallery/big/<?=$photo->image?>" class='colorbox-image' rel="group-1"><i class="icon-search"></i></a>
                                        <a href="javascript://" onclick="deleteS(this,'<?=$photo->id?>','<?=$photo->image?>');"><i class="icon-trash"></i></a>
                                    </div>
                                </div>
                            </li>
                            <?php
                            }
                        }
                        ?>
                        </ul>
                        <iframe name="upload_iframe" id="upload_iframe" style="display:none;"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var ele = "";
	var sid = "0";
	var img = "";
	function openUpload()
	{
		//$("#new-service-title").val("");
		$("#addSL").removeClass("icon-spinner");
		$("#addSL").removeClass("icon-spin");
		$("#addS").attr("disabled",false);
		$("#removeImage").trigger("click");
		$("#openUpload").trigger("click");
		$("#img_title").val("");
	}
	function addNS()
	{
		upload_field = document.getElementById("imagefile");
		iframe = "upload_iframe";
		// Checking file type
		var re_text = /\.jpg|\.png|\.gif|\.jpeg/i;
		var filename = upload_field.value;
		if (filename.search(re_text) == -1) 
		{
			alert("File should be either jpg or gif or jpeg or png");
			$("#removeImage").trigger("click");
			return false;
		}
		else
		{
			$("#addSL").addClass("icon-spinner");
			$("#addSL").addClass("icon-spin");
			$("#addS").attr("disabled",true);
		}
		//document.getElementById('picture_preview').innerHTML = '<div><img src="images/progressbar.gif" border="0" /></div>';
		upload_field.form.action = '<?=HOST?>api/portfolio_add.php';
		upload_field.form.target = iframe;
		upload_field.form.submit();
		//loader = "<img src='<?php echo HOST ?>/img/loader1.gif' class='review_img'/>";
		//document.getElementById(tid).innerHTML = loader;
		upload_field.form.action = '';
		upload_field.form.target = '';
	}
	function uploadDone(container)
	{
		$("#addSC").trigger("click");
		$("#imageGallery").prepend(container);
		$("#imageGallery").children("li").first().fadeIn(1000);
		resetColorBox();
		//alert(container);
	}
	function deleteS(ele,id,timg)
	{
		sid = id;
		img = timg;
		bootbox.confirm("Do you really want to remove this Image?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).parent("div").parent("div").parent("li").fadeOut(1000);
					$.ajax({
						url:"<?=HOST?>api/portfolio_add.php",
						type:"POST",
						data:"action=delete&id="+sid+"&img="+img,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
	function resetColorBox()
	{
		if($(".colorbox-image").length > 0){
			$(".colorbox-image").colorbox({
				maxWidth: "90%",
				maxHeight: "90%",
				rel: $(this).attr("rel")
			});
		}
	}
</script>