<?php
error_reporting(0);
if($_SESSION['Authenticate']!="Yes")
{
	$f3->reroute("/login");
}
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!-- Apple devices fullscreen -->
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<!-- Apple devices fullscreen -->
	<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	
	<title><?=$title?></title>
	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap.min.css">
	<!-- Bootstrap responsive -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap-responsive.min.css">
	<!-- jQuery UI -->
	<link rel="stylesheet" href="<?=CSS?>plugins/jquery-ui/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="<?=CSS?>plugins/jquery-ui/smoothness/jquery.ui.theme.css">
    
	<!-- chosen -->
	<link rel="stylesheet" href="<?=CSS?>plugins/chosen/chosen.css">
	<!-- select2 -->
	<link rel="stylesheet" href="<?=CSS?>plugins/select2/select2.css">
	<!-- colorbox -->
	<link rel="stylesheet" href="<?=CSS?>plugins/colorbox/colorbox.css">
	<!-- Theme CSS -->
	<link rel="stylesheet" href="<?=CSS?>style.css">
	<!-- Color CSS -->
	<link rel="stylesheet" href="<?=CSS?>themes.css">
	<link rel="stylesheet" href="<?=CSS?>custom.css">

	<!-- jQuery -->
	<script src="<?=JS?>jquery.min.js"></script>
	
	
	<!-- Nice Scroll -->
	<script src="<?=JS?>plugins/nicescroll/jquery.nicescroll.min.js"></script>
	<!-- jQuery UI -->
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.core.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.widget.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.mouse.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.draggable.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.resizable.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.sortable.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.selectable.min.js"></script>
	<script src="<?=JS?>plugins/jquery-ui/jquery.ui.droppable.min.js"></script>
	<!-- Touch enable for jquery UI -->
	<script src="<?=JS?>plugins/touch-punch/jquery.touch-punch.min.js"></script>
	<!-- slimScroll -->
	<script src="<?=JS?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<!-- Bootstrap -->
	<script src="<?=JS?>bootstrap.min.js"></script>
	<!-- CKEditor -->
	<script src="<?=JS?>plugins/ckeditor/ckeditor.js"></script>
	<!-- Bootbox -->
	<script src="<?=JS?>plugins/bootbox/jquery.bootbox.js"></script>
	
	<!-- imagesLoaded -->
	<script src="<?=JS?>plugins/imagesLoaded/jquery.imagesloaded.min.js"></script>
    <!-- Custom file upload -->
	<script src="<?=JS?>plugins/fileupload/bootstrap-fileupload.min.js"></script>
	<script src="<?=JS?>plugins/mockjax/jquery.mockjax.js"></script>
	<!-- colorbox -->
	<script src="<?=JS?>plugins/colorbox/jquery.colorbox-min.js"></script>
	<!-- Chosen -->
	<script src="<?=JS?>plugins/chosen/chosen.jquery.min.js"></script>
	<!-- select2 -->
	<script src="<?=JS?>plugins/select2/select2.min.js"></script>
    
    
	
	<!-- Theme framework -->
	<script src="<?=JS?>eakroko.min.js"></script>
	<!-- Theme scripts -->
	<script src="<?=JS?>application.min.js"></script>
	<!-- Just for demonstration -->
	<script src="<?=JS?>demonstration.min.js"></script>
    
	<!--[if lte IE 9]>
		<script src="<?=JS?>plugins/placeholder/jquery.placeholder.min.js"></script>
		<script>
			$(document).ready(function() {
				$('input, textarea').placeholder();
			});
		</script>
	<![endif]-->

	<!-- Favicon -->
	<link rel="shortcut icon" href="<?=FHOST?>images/favicon.png" />
	<!-- Apple devices Homescreen icon -->
	<link rel="apple-touch-icon-precomposed" href="<?=IMG?>apple-touch-icon-precomposed.png" />
    
</head>

<body data-layout-sidebar="fixed" data-layout-topbar="fixed" data-layout="fixed" class="theme-teal" data-theme="theme-teal">

	<div id="navigation">
		<div class="container-fluid">
			<a href="#" id="brand">Softel Solutions</a>
			<ul class='main-nav'>
				<li class="<?=($page=="index")?"active":"";?>">
					<a href="<?=HOST?>">
						<span>Dashboard</span>
					</a>
				</li>
                <li class="<?=($page=="portfolio")?"active":"";?>">
					<a href="<?=HOST?>portfolio">
						<span>Portfolio</span>
					</a>
				</li>
                <li class="<?=($page=="pages")?"active":"";?>">
					<a href="javascript://" data-toggle="dropdown" class='dropdown-toggle'>
						<span>Pages</span>
                        <span class="caret"></span>
					</a>
                    <ul class="dropdown-menu">
                        <?php
						$get_pages = new Pages();
						$get_pages = $get_pages->search();
						if($get_pages)
						{
							foreach($get_pages as $cPage)
							{
								?>
                                <li class="<?=($page=="pages" && $id==$cPage->id)?"active":"";?>">
                                    <a href="<?=HOST?>pages/<?=$cPage->id?>"><?=$cPage->title;?></a>
                                </li>
                                <?php
							}
						}
						?>
                    </ul>
				</li>
                <li class="<?=($page=="browse-positions")?"active":"";?>">
					<a href="<?=HOST?>browse-positions">
						<span>Browse Positions</span>
					</a>
				</li>
			</ul>
			<div class="user">
				<div class="dropdown" style="line-height:27px;">
					<a href="#" class='dropdown-toggle' data-toggle="dropdown"><?=$_SESSION['email'];?> <i class="icon-cog"></i></a>
					<ul class="dropdown-menu pull-right">
						<li>
							<a href="<?=HOST?>login">Sign out</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid nav-hidden" id="content">
		<div id="left" class="">
			
		</div>
		
    