<?php
$objC = new Category();
$get_val = new Category();
$get_val = $get_val->search("pa=0");
?>
<div id="main">
	<div id="new-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Add new category</h3>
		</div>
		<form id="frmNewGallery" method="post" class='form-horizontal form-bordered'>
			<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Category name</label>
					<div class="controls">
						<input type="text" name="new-gallery-title" id="new-gallery-title" class="input-block-level" placeholder="Enter category name">
                        <input type="hidden" name="action" value="add" />
					</div>
				</div>
                <div class="control-group hide">
					<label for="service-title" class="control-label">Category</label>
					<div class="controls">
						<select class="input-block-level" name="new-gallery-parent" id="new-gallery-parent">
                        <option value="0">Main</option>
                        <?php
						if($get_val)
						{
							foreach($get_val as $category)
							{
							?>
                            <option value="<?=$category->id?>"><?=$category->name?></option>
                            <?php
								$level1 = $objC->search("pa=".$category->id);
								if($level1)
								{
									foreach($level1 as $category1)
									{
									?>
									<option value="<?=$category1->id?>" style="padding-left:15px;"><?=$category1->name?></option>
									<?php
										$level2 = $objC->search("pa=".$category1->id);
										if($level2)
										{
											foreach($level2 as $category2)
											{
											?>
											<option value="<?=$category2->id?>" style="padding-left:30px;"><?=$category2->name?></option>
											<?php
											}
										}		
									}
								}		
							}
						}
						?>
                        </select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
                <button type="button" id="addS" class="btn btn-primary" onclick="addNS();"><i class="icon-save"></i> Save <i id="addSL" class=""></i></button>
                <button type="button" id="addSC" data-dismiss="modal" aria-hidden="true" class="btn">Cancel</button>
                <button type="submit" id="add-submit" class="hide"></button>
			</div>
		</form>

	</div>
    <div id="edit-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Edit Category</h3>
		</div>
		<form id="frmEditGallery"  method="post"class='new-task-form form-horizontal form-bordered'>
			<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Categoty name</label>
					<div class="controls">
						<input type="text" name="edit-gallery-title" id="edit-gallery-title" class="input-block-level" placeholder="Enter category name">
                        <input type="hidden" name="action" value="edit" />
                        <input type="hidden" name="id" id="edit-id" value="0" />
					</div>
				</div>
			</div>
			<div class="modal-footer">
                <button type="button" id="editS" class="btn btn-primary" onclick="editNS();"><i class="icon-save"></i> Save</button>
                <button type="button" id="editSC" data-dismiss="modal" aria-hidden="true" class="btn" >Cancel</button>
			</div>
		</form>

	</div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span8">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Portfolio
                        </h3>
                        <div class="actions">
                        	<a href="javascript://" onclick="openAdd();" class='btn'><i class="icon-plus-sign"></i> Add Category</a>
                            <a id="openAdd" href="#new-service" data-toggle="modal" class='btn hide'></a>
                            <a id="openEdit" href="#edit-service" data-toggle="modal" class='btn hide'></a>
                        </div>
                    </div>
                    <div class="box-content nopadding">
                        <table class="table table-hover table-nomargin table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="75">Action</th>
                                </tr>
                            </thead>
                            <tbody id="services-list">
                            <?php
							if($get_val)
							{
								foreach($get_val as $category)
								{
								?>
								<tr>
                                    <td><i class="icon-hand-right"></i> <span id="title_<?=$category->id?>"><?=$category->name?></span></td>
                                    <td>
                                        <a data-original-title="Add Photos" href="<?=HOST?>portfolio/<?=$category->id?>" class="btn btn-mini btn-primary" rel="tooltip" title=""><i class="icon-plus"></i></a>
                                        <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$category->id?>')" class="btn btn-mini btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
                                        <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$category->id?>')" class="btn btn-mini btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
                                    </td>
                                </tr>
								<?php
									$level1 = $objC->search("pa=".$category->id);
									if($level1)
									{
										foreach($level1 as $category1)
										{
										?>
										<tr>
                                            <td style="padding-left:30px;"><i class="icon-arrow-right"></i> <span id="title_<?=$category1->id?>"><?=$category1->name?></span></td>
                                            <td>
                                            <a data-original-title="Add Photos" href="<?=HOST?>portfolio/<?=$category1->id?>" class="btn btn-mini btn-primary" rel="tooltip" title=""><i class="icon-plus"></i></a>
                                                <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$category1->id?>')" class="btn btn-mini btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
                                                <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$category1->id?>')" class="btn btn-mini btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
                                            </td>
                                        </tr>
										<?php
											$level2 = $objC->search("pa=".$category1->id);
											if($level2)
											{
												foreach($level2 as $category2)
												{
												?>
												<tr>
                                                    <td style="padding-left:60px;"><i class="glyphicon-right_arrow"></i> <span id="title_<?=$category2->id?>"><?=$category2->name?></span></td>
                                                    <td>
                                                    	<a data-original-title="Add Photos" href="<?=HOST?>portfolio/<?=$category2->id?>" class="btn btn-mini btn-primary" rel="tooltip" title=""><i class="icon-plus"></i></a>
                                                        <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$category2->id?>')" class="btn btn-mini btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
                                                        <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$category2->id?>')" class="btn btn-mini btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
                                                    </td>
                                                </tr>
												<?php
													$level3 = $objC->search("pa=".$category2->id);
													if($level3)
													{
														foreach($level3 as $category3)
														{
														?>
														<tr>
															<td style="padding-left:90px;"><i class="icon-circle"></i> <span id="title_<?=$category3->id?>"><?=$category3->name?></span></td>
															<td>
                                                            	<a data-original-title="Add Photos" href="<?=HOST?>portfolio/<?=$category3->id?>" class="btn btn-mini btn-primary" rel="tooltip" title=""><i class="icon-plus"></i></a>
																<a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$category3->id?>')" class="btn btn-mini btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
																<a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$category3->id?>')" class="btn btn-mini btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
															</td>
														</tr>
														<?php
														}
													}
												}
											}		
										}
									}		
								}
							}
							?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var ele = "";
	var sid = "0";
	function openAdd()
	{
		$("#new-service-title").val("");
		$("#addSL").removeClass("icon-spinner");
		$("#addSL").removeClass("icon-spin");
		$("#addS").attr("disabled",false);
		$("#openAdd").trigger("click");
	}
	function openEdit(id)
	{
		$("#edit-gallery-title").val($("#title_"+id).html());
		$("#edit-id").val(id);
		$("#openEdit").trigger("click");
	}
	function editNS()
	{
		var id = $("#edit-id").val();
		var frm = $("#frmEditGallery").serialize();
		$("#editSC").trigger("click");
		
		$("#title_"+id).html($("#edit-gallery-title").val());
		$.ajax({
			url:"<?=HOST?>portfolio",
			type:"POST",
			data:frm,
			success:function(res){
			}
		})
	}
	function addNS()
	{
		$("#addSL").addClass("icon-spinner");
		$("#addSL").addClass("icon-spin");
		$("#addS").attr("disabled",true);
		$("#add-submit").trigger("click");
	}
	function deleteS(ele,id)
	{
		sid = id;
		bootbox.confirm("Do you really want to remove this Category?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).parent("td").parent("tr").remove();
					$.ajax({
						url:"<?=HOST?>portfolio",
						type:"POST",
						data:"action=delete&id="+sid,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
</script>