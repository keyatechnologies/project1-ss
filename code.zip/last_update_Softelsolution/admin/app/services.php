<div id="main">
	<div id="new-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Add new service</h3>
		</div>
		<form id="frmNewService" class='new-task-form form-horizontal form-bordered'>
			<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Service Title</label>
					<div class="controls">
						<input type="text" name="new-service-title" id="new-service-title" class="input-block-level" placeholder="Enter Service Title">
                        <input type="hidden" name="action" value="add" />
					</div>
				</div>
			</div>
			<div class="modal-footer">
                <button type="button" id="addS" class="btn btn-primary" onclick="addNS();"><i class="icon-save"></i> Save <i id="addSL" class=""></i></button>
                <button type="button" id="addSC" data-dismiss="modal" aria-hidden="true" class="btn">Cancel</button>
			</div>
		</form>

	</div>
    <div id="edit-service" class="modal hide" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Edit service</h3>
		</div>
		<form id="frmEditService" class='new-task-form form-horizontal form-bordered'>
			<div class="modal-body nopadding">
				<div class="control-group">
					<label for="service-title" class="control-label">Service Title</label>
					<div class="controls">
						<input type="text" name="edit-service-title" id="edit-service-title" class="input-block-level" placeholder="Enter Service Title">
                        <input type="hidden" name="action" value="edit" />
                        <input type="hidden" name="id" id="edit-id" value="0" />
					</div>
				</div>
			</div>
			<div class="modal-footer">
                <button type="button" id="editS" class="btn btn-primary" onclick="editNS();"><i class="icon-save"></i> Save</button>
                <button type="button" id="editSC" data-dismiss="modal" aria-hidden="true" class="btn" >Cancel</button>
			</div>
		</form>

	</div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span8">
                <div class="box box-color box-condensed box-bordered">
                    <div class="box-title">
                        <h3>
                            <i class="icon-reorder"></i>
                            Services
                        </h3>
                        <div class="actions">
                        	<a href="javascript://" onclick="openAdd();" class='btn'><i class="icon-plus-sign"></i> Add Service</a>
                            <a id="openAdd" href="#new-service" data-toggle="modal" class='btn hide'></a>
                            <a id="openEdit" href="#edit-service" data-toggle="modal" class='btn hide'></a>
                        </div>
                    </div>
                    <div class="box-content nopadding">
                        <table class="table table-hover table-nomargin table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="75">Action</th>
                                </tr>
                            </thead>
                            <tbody id="services-list">
                            <?php
							$get_val = new Services();
							$get_val = $get_val->search("","","id desc");
							if($get_val)
							{
								foreach($get_val as $service)
								{
									?>
									<tr>
										<td id="title_<?=$service->id?>"><?=$service->title?></td>
										<td>
											<a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$service->id?>')" class="btn btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
											<a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$service->id?>')" class="btn btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
										</td>
									</tr>
									<?php
								}
							}
							?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var ele = "";
	var sid = "0";
	function openAdd()
	{
		$("#new-service-title").val("");
		$("#addSL").removeClass("icon-spinner");
		$("#addSL").removeClass("icon-spin");
		$("#addS").attr("disabled",false);
		$("#openAdd").trigger("click");
	}
	function openEdit(id)
	{
		$("#edit-service-title").val($("#title_"+id).html());
		$("#edit-id").val(id);
		$("#openEdit").trigger("click");
	}
	function editNS()
	{
		var id = $("#edit-id").val();
		var frm = $("#frmEditService").serialize();
		$("#editSC").trigger("click");
		
		$("#title_"+id).html($("#edit-service-title").val());
		$.ajax({
			url:"<?=HOST?>services",
			type:"POST",
			data:frm,
			success:function(res){
			}
		})
	}
	function addNS()
	{
		$("#addSL").addClass("icon-spinner");
		$("#addSL").addClass("icon-spin");
		$("#addS").attr("disabled",true);
		var frm = $("#frmNewService").serialize();
		$.ajax({
			url:"<?=HOST?>services",
			type:"POST",
			data:frm,
			success:function(res){
				$("#addSC").trigger("click");
				$("#services-list").prepend(res);
			}
		})
	}
	function deleteS(ele,id)
	{
		sid = id;
		bootbox.confirm("Do you really want to remove this Service?","Cancel","Yes, remove",
			function(e)
			{
				if(e)
				{
					// if yes
					$(ele).parent("td").parent("tr").remove();
					$.ajax({
						url:"<?=HOST?>services",
						type:"POST",
						data:"action=delete&id="+sid,
						success:function(res){
						},
						error:function(e){
						}
					});
				}
			}
		);
	}
</script>