<?php
error_reporting(0);
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!-- Apple devices fullscreen -->
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<!-- Apple devices fullscreen -->
	<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	
	<title>Softel Solutions - Login</title>
    <link href="<?=FHOST?>images/favicon.png" rel="shortcut icon">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap.min.css">
	<!-- Bootstrap responsive -->
	<link rel="stylesheet" href="<?=CSS?>bootstrap-responsive.min.css">
    <link rel="stylesheet" href="<?=CSS?>plugins/icheck/all.css">
	<!-- Theme CSS -->
	<link rel="stylesheet" href="<?=CSS?>style.css">
	<!-- Color CSS -->
	<link rel="stylesheet" href="<?=CSS?>themes.css">


	<!-- jQuery -->
	<script src="<?=JS?>jquery.min.js"></script>
	
	<!-- Nice Scroll -->
	<script src="<?=JS?>plugins/nicescroll/jquery.nicescroll.min.js"></script>
	<!-- Validation -->
	<script src="<?=JS?>plugins/validation/jquery.validate.min.js"></script>
	<script src="<?=JS?>plugins/validation/additional-methods.min.js"></script>
    <!-- icheck -->
	<script src="<?=JS?>plugins/icheck/jquery.icheck.min.js"></script>
	<!-- Bootstrap -->
	<script src="<?=JS?>bootstrap.min.js"></script>
	<script src="<?=JS?>eakroko.js"></script>

	<!--[if lte IE 9]>
		<script src="<?=JS?>plugins/placeholder/jquery.placeholder.min.js"></script>
		<script>
			$(document).ready(function() {
				$('input, textarea').placeholder();
			});
		</script>
	<![endif]-->
	

	<!-- Favicon -->
	<link rel="shortcut icon" href="<?=HOST?>img/favicon.ico" />
	<!-- Apple devices Homescreen icon -->
	<link rel="apple-touch-icon-precomposed" href="<?=HOST?>img/apple-touch-icon-precomposed.png" />

</head>

<body class='login theme-teal' data-theme="theme-teal">
	<div class="wrapper">
		<h1 style="text-align:center; color:#FFF;">Admin Panel</h1>
		<div class="login-body">
        	
			<h2><img src="<?=FHOST?>images/logo.png"></h2>
            <?php
			if($_SESSION['Authenticate'])
			{
				unset($_SESSION['Authenticate']);
			}
			?>
			<form action="" method='post' class='form-validate' id="test">
				<div class="control-group">
					<div class="email controls">
						<input type="text" name='uemail' value="<?=$_SESSION['a']?>" placeholder="Email address" class='input-block-level' data-rule-required="true" data-rule-email="true">
					</div>
				</div>
				<div class="control-group">
					<div class="pw controls">
						<input type="password" name="upw" placeholder="Password" class='input-block-level' data-rule-required="true">
					</div>
				</div>
				<div class="submit">
					<div class="remember hide">
						<input type="checkbox" name="remember" class='icheck-me' data-skin="square" data-color="blue" id="remember"> <label for="remember">Remember me</label>
					</div>
                    <input type="hidden" name="login" value="login">
					<input type="submit" value="Sign me in" class='btn btn-primary'>
				</div>
			</form>
            <?php
			if($_SESSION['a']){unset($_SESSION['a']);}
			if($_SESSION['login_error'])
			{
				unset($_SESSION['login_error']);
				?>
                <div class="alert alert-error" style="margin-bottom:0px !important;">
                    <button data-dismiss="alert" class="close" type="button">×</button>
                    <strong>Error!</strong> Invalid email or password.
                </div>
                <?php
			}
			?>
			<div class="forget" style="margin-top:0px !important;">
				<a href="<?=FHOST?>"><span>Back to site</span></a>
			</div>
		</div>
	</div>
</body>

</html>
