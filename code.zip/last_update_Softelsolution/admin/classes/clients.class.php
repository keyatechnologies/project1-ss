<?php
class Clients
{ 
	var $id;
	var $title;

	var $udata;

	function clients($var=''){
			$this->id =0;
			return ($this->setById($var));
	}

	function setById($var=''){
		$sql = "SELECT * FROM clients WHERE id = ".$var;
        
		$res=mysql_query($sql);	
	
        if(!$res || !mysql_num_rows($res))
            return NULL;

        $row=mysql_fetch_assoc($res);
		foreach($row as $key=>$value)
			$this->$key = $value;
    }

	function getById($var=''){

        $sql="SELECT * FROM clients WHERE id = ".$var;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
			
        $row = mysql_fetch_object($res);
		
		return $row;
    }

	function search($condition='',$orderby='',$groupby=''){

        $sql="SELECT * FROM clients";
		if($condition != '')
			$sql .= " WHERE ".$condition;
		if($orderby != '')
			$sql .= " ORDER BY ".$orderby;
		if($groupby != '')
			$sql .= " GROUP BY ".$groupby;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
		$total_row = array();		
        while($row=mysql_fetch_object($res))
		{
			$total_row[] = $row;			
        }		
		return $total_row;
    }

	function insert(){
		$ins_query = "INSERT INTO clients SET title= '".$this->title."'";
		$res_query = mysql_query($ins_query) or die(mysql_error());
	}

	function update(){
		$upd_query = "UPDATE clients SET title= '".$this->title."' WHERE id = ".$this->id;
		$res_update = mysql_query($upd_query) or die(mysql_error());
	}

	function delete($var){
		$del_query = "DELETE FROM clients WHERE id = ".$var;				
		$res_delete = mysql_query($del_query) or die(mysql_error());
	}

	function deleteall(){
		mysql_query("DELETE FROM clients");
	}
}
?>