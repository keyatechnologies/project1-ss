<?php
class Testimonial
{ 
	var $id;
	var $name;
	var $email;
	var $title;
	var $testimonial;
	var $status;

	var $udata;

	function testimonial($var=''){
			$this->id =0;
			return ($this->setById($var));
	}

	function setById($var=''){
		$sql = "SELECT * FROM testimonial WHERE id = ".$var;
        
		$res=mysql_query($sql);	
	
        if(!$res || !mysql_num_rows($res))
            return NULL;

        $row=mysql_fetch_assoc($res);
		foreach($row as $key=>$value)
			$this->$key = $value;
    }

	function getById($var=''){

        $sql="SELECT * FROM testimonial WHERE id = ".$var;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
			
        $row = mysql_fetch_object($res);
		
		return $row;
    }

	function search($condition='',$orderby='',$groupby=''){

        $sql="SELECT * FROM testimonial";
		if($condition != '')
			$sql .= " WHERE ".$condition;
		if($orderby != '')
			$sql .= " ORDER BY ".$orderby;
		if($groupby != '')
			$sql .= " GROUP BY ".$groupby;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
		$total_row = array();		
        while($row=mysql_fetch_object($res))
		{
			$total_row[] = $row;			
        }		
		return $total_row;
    }

	function insert(){
		$ins_query = "INSERT INTO testimonial SET name= '".$this->name."',email= '".$this->email."',title= '".$this->title."',testimonial= '".$this->testimonial."',status= '".$this->status."'";
		$res_query = mysql_query($ins_query) or die(mysql_error());
	}

	function update(){
		$upd_query = "UPDATE testimonial SET name= '".$this->name."',email= '".$this->email."',title= '".$this->title."',testimonial= '".$this->testimonial."',status= '".$this->status."' WHERE id = ".$this->id;
		$res_update = mysql_query($upd_query) or die(mysql_error());
	}

	function delete($var){
		$del_query = "DELETE FROM testimonial WHERE id = ".$var;				
		$res_delete = mysql_query($del_query) or die(mysql_error());
	}

	function deleteall(){
		mysql_query("DELETE FROM testimonial");
	}
}
?>