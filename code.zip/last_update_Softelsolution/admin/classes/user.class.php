<?php
class User
{ 
	var $id;
	var $email;
	var $password;

	var $udata;

	function user($var=''){
			$this->id =0;
			return ($this->setById($var));
	}

	function setById($var=''){
		$sql = "SELECT * FROM user WHERE id = ".$var;
        
		$res=mysql_query($sql);	
	
        if(!$res || !mysql_num_rows($res))
            return NULL;

        $row=mysql_fetch_assoc($res);
		foreach($row as $key=>$value)
			$this->$key = $value;
    }

	function getById($var=''){

        $sql="SELECT * FROM user WHERE id = ".$var;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
			
        $row = mysql_fetch_object($res);
		
		return $row;
    }

	function search($condition='',$orderby='',$groupby=''){

        $sql="SELECT * FROM user";
		if($condition != '')
			$sql .= " WHERE ".$condition;
		if($orderby != '')
			$sql .= " ORDER BY ".$orderby;
		if($groupby != '')
			$sql .= " GROUP BY ".$groupby;

        $res=mysql_query($sql);
        if(!$res || !mysql_num_rows($res))
            return NULL;
		$total_row = array();		
        while($row=mysql_fetch_object($res))
		{
			$total_row[] = $row;			
        }		
		return $total_row;
    }

	function insert(){
		$ins_query = "INSERT INTO user SET email= '".$this->email."',password= '".$this->password."'";
		$res_query = mysql_query($ins_query) or die(mysql_error());
	}

	function update(){
		$upd_query = "UPDATE user SET email= '".$this->email."',password= '".$this->password."' WHERE id = ".$this->id;
		$res_update = mysql_query($upd_query) or die(mysql_error());
	}

	function delete($var){
		$del_query = "DELETE FROM user WHERE id = ".$var;				
		$res_delete = mysql_query($del_query) or die(mysql_error());
	}

	function deleteall(){
		mysql_query("DELETE FROM user");
	}
}
?>