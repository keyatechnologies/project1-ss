<?php
error_reporting(0);
function slugify($text)
{ 
  // replace non letter or digits by -
  $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

  // trim
  $text = trim($text, '-');

  // transliterate
  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

  // lowercase
  $text = strtolower($text);

  // remove unwanted characters
  $text = preg_replace('~[^-\w]+~', '', $text);

  if (empty($text))
  {
    return false;
  }

  return $text;
}
if($_REQUEST['action']=="delete")
{
	$delete_category = new Category();
	$delete_category->delete($_REQUEST["id"]);
	echo "Success";
	exit;
}
if($_REQUEST['action']=="edit")
{
	$slug= slugify($_REQUEST['edit-gallery-title']);
	$edit_category = new Category($_REQUEST["id"]);
	$edit_category->name = setGPC($_REQUEST['edit-gallery-title'],"");
	if($slug)
	{
		$edit_category->slug = $slug;
	}
	//$edit_category->pa = $_REQUEST['edit-gallery-parent'];
	$edit_category->update();
	exit;
}
if($_REQUEST['action']=="add")
{
	$slug= slugify($_REQUEST['new-gallery-title']);
	
	$add_category = new Category();
	$add_category->name = setGPC($_REQUEST['new-gallery-title'],"");
	$add_category->pa = $_REQUEST['new-gallery-parent'];
	if($slug)
	{
		$add_category->slug = $slug;
	}
	$add_category->insert();
	$f3->reroute("/portfolio");
	/*
	$edit_page = new Pages($id);
	$edit_page->title = setGPC($_REQUEST['pagetitle'],"");
	$edit_page->description = setGPC($_REQUEST['pagedesc'],"");
	$edit_page->update();

	$_SESSION['success']=1;
	$f3->reroute("/pages/".$id);
	//header("Location:".HOST."pages/".$slug);
	exit;
	*/
}
?>