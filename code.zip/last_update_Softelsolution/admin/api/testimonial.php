<?php
if($_REQUEST['action']=="delete")
{
	$delete_testimonial = new Testimonial();
	$delete_testimonial->delete($_REQUEST["id"]);
	exit;
}
if($_REQUEST['action']=="edit")
{
	$edit_testimonial = new Testimonial($_REQUEST["id"]);
	$edit_testimonial->status = "1";
	$edit_testimonial->update();
	exit;
}
?>