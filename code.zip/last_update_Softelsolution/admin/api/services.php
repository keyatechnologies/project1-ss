<?php
if($_REQUEST['action']=="delete")
{
	$delete_service = new Services();
	$delete_service->delete($_REQUEST["id"]);
	echo "Success";
	exit;
}
if($_REQUEST['action']=="edit")
{
	$edit_service = new Services($_REQUEST["id"]);
	$edit_service->title = setGPC($_REQUEST['edit-service-title'],"");
	$edit_service->update();
}
if($_REQUEST['action']=="add")
{
	$add_service = new Services();
	$add_service->title = setGPC($_REQUEST['new-service-title'],"");
	$add_service->insert();
	$lid = mysql_insert_id();
	$get_val = new Services();
	$service = $get_val->getById($lid);
	?>
    <tr>
        <td id="title_<?=$service->id?>"><?=$service->title?></td>
        <td>
            <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$service->id?>')" class="btn btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
            <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$service->id?>')" class="btn btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
        </td>
    </tr>
    <?php
	/*
	$edit_page = new Pages($id);
	$edit_page->title = setGPC($_REQUEST['pagetitle'],"");
	$edit_page->description = setGPC($_REQUEST['pagedesc'],"");
	$edit_page->update();

	$_SESSION['success']=1;
	$f3->reroute("/pages/".$id);
	//header("Location:".HOST."pages/".$slug);
	exit;
	*/
}
?>