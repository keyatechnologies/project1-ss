<?php
error_reporting(0);
if($_POST['login']=="login")
{
	$_SESSION['a'] = $_POST['uemail'];
	$objUser = new Users();
	$objUser = $objUser->search("email='".setGPC($_POST['uemail'],"")."' and password = '".setGPC($_POST['upw'],"")."'");
	if($objUser)
	{
		foreach($objUser as $user)
		{
			$_SESSION['Authenticate']="Yes";
			$_SESSION['email'] = $user->email;
			$f3->reroute("/");
			break;
		}
	}
	else
	{
		$_SESSION['login_error'] = true; 
	}
}
else
{
	$_SESSION['login_error'] = true; 
}
$f3->reroute("/login");
?>