<?php
if(isset($_REQUEST['submit']))
{
	$edit_page = new Pages($id);
	$edit_page->title = setGPC($_REQUEST['pagetitle'],"");
	$edit_page->description = setGPC($_REQUEST['ck'],"");
	$edit_page->update();

	$_SESSION['success']=1;
	$f3->reroute("/pages/".$id);
	//header("Location:".HOST."pages/".$slug);
	exit;
}
?>