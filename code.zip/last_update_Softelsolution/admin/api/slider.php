<?php
require_once("../include/dbconnect.php");
require_once("../../model/slider.class.php");
require_once("../../model/image.class.php");

# Delete Image
function deleteImage($file)
{
	if(file_exists($file))
	{
		unlink($file);
	}
}
# End Delete Image
function uploadImage($file)
{	
	if($file['type'] == 'image/gif' || $file['type'] == 'image/png' || $file['type'] == 'image/jpeg' || $file['type'] == 'image/jpg')
	{
		$image = new Upload($file);
		if ($image->uploaded) 
		{
			$filename = time().uniqid();
			# copy thumb image
			$image->file_new_name_body = $filename;
			$image->image_resize            = true;
			$image->image_y           		= 480;
			$image->image_x                 = 1200;
			$image->Process("../../upload/slider/big/");
			
			$image->file_new_name_body = $filename;
			$image->image_resize            = true;
			$image->image_y           		= 110;
			$image->image_x                 = 200;
			$image->Process("../../upload/slider/thumb/");
			
			
			
			# Check Image uploaded 
			if($image->processed) 
			{
				//echo $image->error;
				$error = false;
				$new = $image->file_dst_name;
			}
			else
			{
				// if upload file failed for some reasons
				// i.e. the server didn't receive the file
				//echo $image->error;
				$error = true;
			}
			$image->Clean();
			if(!$error)
				return $new;
		}
		else 
		{
			// if upload file failed for some reasons
			// i.e. the server didn't receive the file
			//echo $image->error ;
			return false;
		}
	}
	else
	{
		return false;
	}
}

if($_REQUEST['action']=="delete")
{
	if($_REQUEST["img"] != "")
	{
		deleteImage("../../upload/slider/thumb/".$_REQUEST["img"]);
		deleteImage("../../upload/slider/big/".$_REQUEST["img"]);
	}
	$delete_slider = new Slider();
	$delete_slider->delete($_REQUEST["id"]);
	exit;
}
if($_REQUEST['action']=="add")
{
	if($_FILES['imagefile']['name'] !="")
	{
		$ext = end(explode(".",$_FILES['imagefile']['name']));
		$file = uploadImage($_FILES['imagefile']);
		$add_slider = new Slider();
		$add_slider->slide = $file;
		$add_slider->insert();
		$id = mysql_insert_id();
		?>
        <script type="text/javascript">
		var container = "";
			container += '<li style="display:none;">';
			container += '<a href="javascript://">';
			container += '<img src="../upload/slider/thumb/<?=$file?>" alt="">'
			container += '</a>';
			container += '<div class="extras">';
			container += '<div class="extras-inner">';
			container += '<a href="../upload/slider/big/<?=$file?>" class="colorbox-image" rel="group-1"><i class="icon-search"></i></a>';
			container += '<a href="javascript://" onclick="deleteS(this,\'<?=$id?>\',\'<?=$file?>\');"><i class="icon-trash"></i></a>';
			container += '</div>';
			container += '</div>';
			container += '</li>';
			parent.uploadDone(container);
	</script>
        <?php
	}
	exit;
}
?>