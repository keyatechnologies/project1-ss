<?php
if($_REQUEST['action']=="delete")
{
	$delete_client = new Clients();
	$delete_client->delete($_REQUEST["id"]);
	exit;
}
if($_REQUEST['action']=="edit")
{
	$edit_client = new Clients($_REQUEST["id"]);
	$edit_client->title = setGPC($_REQUEST['edit-client-title'],"");
	$edit_client->update();
	exit;
}
if($_REQUEST['action']=="add")
{
	$add_client = new Clients();
	$add_client->title = setGPC($_REQUEST['new-client-title'],"");
	$add_client->insert();
	$lid = mysql_insert_id();
	$get_val = new Clients();
	$client = $get_val->getById($lid);
	?>
    <tr>
        <td id="title_<?=$client->id?>"><?=$client->title?></td>
        <td>
            <a data-original-title="Edit" href="javascript://" onclick="openEdit('<?=$client->id?>')" class="btn btn-green" rel="tooltip" title=""><i class="icon-edit"></i></a>
            <a data-original-title="Delete" href="javascript://" onclick="deleteS(this,'<?=$client->id?>')" class="btn btn-red" rel="tooltip" title=""><i class="icon-remove"></i></a>
        </td>
    </tr>
    <?php
	exit;
}
?>